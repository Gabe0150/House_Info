package app;
import cooling.AC;
import buildingunit.Room;
import building.House;

public class Controller {

    //-----------------------------------------------
    public static void main(String[] args){

        yourInfoHeader();
        AC.acStats();

        Room kitchen = new Room("Kitchen", "White" , 15.5 , 10.0 , 78.0);
        kitchen.roomStats("");

        Room livingRoom = new Room("Living Room" , "Tan" , 25.00 , 20.70 , 76.50);
        livingRoom.roomStats("");

        Room bathroom = new Room("Bathroom" , "White" , 15.00 , 10.00 , 74.30);
        bathroom.roomStats("");

        Room bedroom = new Room("Bedroom" , "Blue" , 8.00 , 8.00 , 78.00);
        bedroom.roomStats("");

        House myHouse = new House(kitchen , livingRoom , bathroom , bedroom);
        myHouse.displayInfo();

        //----------------------------------------------------------------

        System.out.println("--------------------------------------------");
        System.out.println("What is the house's total square feet: " + myHouse.getHouseSquareFeet() );
        System.out.println("--------------------------------------------");
        System.out.println();

        //----------------------------------------------------------------

        AC.acStats();

        //----------------------------------------------------------------
        //----------------------------------------------------------------

        System.out.println("---------------------------------------");
        System.out.println("Call by Value");
        System.out.println("---------------------------------------");
        System.out.println();

        AC.changeTemperatureDown(livingRoom.getTemperature(), 5);

        livingRoom.roomStats("");

        AC.changeTemperatureDown(myHouse.getKitchen().getTemperature(), 3);

        myHouse.getKitchen().roomStats("");

        AC.acStats();

        //-------------------------------------------------
        //-------------------------------------------------

        System.out.println("---------------------------------");
        System.out.println("Call by Reference");
        System.out.println("---------------------------------");
        System.out.println();

        AC.changeTemperatureDown(livingRoom , 5);
        livingRoom.roomStats("");

        AC.changeTemperatureDown(myHouse.getKitchen(), 3);
        myHouse.getKitchen().roomStats("");

        AC.acStats();


    }

    //beginning of yourInfoHeader() method

    public static void yourInfoHeader(){

        System.out.println("===============================");
        System.out.println("PROGRAMMER: " + "Gabriel Lopez");
        System.out.println("PANTHER ID: " + "6289021");
        System.out.println();
        System.out.println("CLASS: \t\t COP2210 ");
        System.out.println("SECTION: \t " + "U02");
        System.out.println("SEMESTER: \t " + "Fall 2024");
        System.out.println("CLASSTIME: \t " + "9:30AM - 12:15PM");
        System.out.println();
        System.out.println("Assignment: " + "LAB 5");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person");
        System.out.println("================================");
        System.out.println();

    }//end yourInfoHeader
}


